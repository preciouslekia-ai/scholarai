import os
import json
import uuid
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, jsonify
import pdfplumber, re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import nltk

# Optional cloud clients
try:
    from elasticsearch import Elasticsearch, helpers
except Exception:
    Elasticsearch = None
try:
    from google.cloud import aiplatform
except Exception:
    aiplatform = None

# Ensure NLTK tokenizer
try:
    nltk.data.find('tokenizers/punkt')
except:
    nltk.download('punkt')

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "data"
DATA_DIR.mkdir(exist_ok=True)

CONFIG_PATH = BASE / "config.json"
DEFAULT_CONFIG = {
    "mode": "cloud",  # "cloud" or "local"
    "elastic": {
        "host": "<ELASTIC_CLOUD_ENDPOINT>",
        "api_key": "<ELASTIC_API_KEY>",
        "index": "scholarai_docs"
    },
    "gcp": {
        "project": "<GCP_PROJECT_ID>",
        "location": "us-central1",
        "embedding_model": "textembedding-gecko", 
        "generation_model": "text-bison@001"
    }
}

if not CONFIG_PATH.exists():
    CONFIG_PATH.write_text(json.dumps(DEFAULT_CONFIG, indent=2))

def load_config():
    return json.loads(CONFIG_PATH.read_text())

def extract_text_from_pdf(path):
    texts=[]
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            txt = page.extract_text()
            if txt:
                texts.append(txt)
    return "\n".join(texts)

def chunk_text(text, max_chars=1000, overlap=200):
    chunks=[]
    start=0
    L=len(text)
    while start < L:
        end = min(start+max_chars, L)
        chunk = text[start:end]
        chunks.append(chunk.strip())
        start = end - overlap
        if start < 0:
            start = 0
        if start >= L:
            break
    return chunks

def simple_sentence_retrieval(text, question):
    sentences = nltk.tokenize.sent_tokenize(text)
    sentences = [re.sub('\s+',' ',s).strip() for s in sentences if len(s.strip())>20]
    if not sentences:
        return "No extractable sentences found."
    vect = TfidfVectorizer(stop_words='english').fit(sentences + [question])
    svecs = vect.transform(sentences)
    qvec = vect.transform([question])
    sims = cosine_similarity(qvec, svecs).flatten()
    top_idx = sims.argsort()[::-1][:3]
    top = [sentences[i] for i in top_idx if sims[i]>0]
    return " ".join(top) if top else "No relevant passages found."

def init_elastic_client(cfg):
    if Elasticsearch is None:
        raise RuntimeError("elasticsearch package not installed")
    host = cfg['elastic']['host']
    api_key = cfg['elastic'].get('api_key')
    # Elastic cloud: pass api_key or basic auth as needed
    es = Elasticsearch(hosts=[host], api_key=api_key)
    return es

def index_document_to_elastic(es, cfg, doc_id, title, chunks, embedding_fn=None):
    index = cfg['elastic']['index']
    # create index if not exists (basic)
    if not es.indices.exists(index=index):
        es.indices.create(index=index, ignore=400)
    actions=[]
    for i, chunk in enumerate(chunks):
        doc = {
            "doc_id": doc_id,
            "title": title,
            "chunk_id": f"{doc_id}_{i}",
            "text": chunk
        }
        # optional: compute embedding
        if embedding_fn:
            emb = embedding_fn(chunk)
            doc['embedding'] = emb
        actions.append({"_op_type":"index", "_index":index, "_id":doc['chunk_id'], "_source":doc})
    if actions:
        helpers.bulk(es, actions)

def query_elastic(es, cfg, question, top_k=3, embedding_fn=None):
    index = cfg['elastic']['index']
    # If embedding_fn available, use vector similarity (requires elastic vector mapping)
    if embedding_fn:
        q_emb = embedding_fn(question)
        # vector search template (requires index mapping with 'embedding' field)
        body = {
            "size": top_k,
            "query": {
                "script_score": {
                    "query": {"match_all": {}},
                    "script": {
                        "source": "cosineSimilarity(params.query_vector, 'embedding') + 1.0",
                        "params": {"query_vector": q_emb}
                    }
                }
            }
        }
        res = es.search(index=index, body=body)
        hits = [hit['_source']['text'] for hit in res['hits']['hits']]
        return hits
    else:
        # fallback: simple BM25 keyword match
        body = {
            "size": top_k,
            "query": {
                "multi_match": {
                    "query": question,
                    "fields": ["title^2","text"]
                }
            }
        }
        res = es.search(index=index, body=body)
        hits = [hit['_source']['text'] for hit in res['hits']['hits']]
        return hits

def init_vertex_client(cfg):
    if aiplatform is None:
        raise RuntimeError("google-cloud-aiplatform package not installed")
    gcp = cfg['gcp']
    aiplatform.init(project=gcp['project'], location=gcp['location'])
    return aiplatform

def vertex_get_embeddings_fn(cfg):
    # returns a function that calls Vertex embeddings when available
    def embed(text):
        # lazy import to avoid errors when package not available
        from google.cloud import aiplatform
        model = cfg['gcp']['embedding_model']
        # note: actual API may differ depending on model; user should adapt
        embedding = aiplatform.VertexAI().get_embeddings(model=model, instances=[text])
        return embedding[0]
    return embed

def vertex_generate_text(cfg, prompt, max_output_tokens=256):
    from google.cloud import aiplatform
    model = cfg['gcp']['generation_model']
    client = aiplatform.TextGenerationModel.from_pretrained(model)
    resp = client.predict(prompt, max_output_tokens=max_output_tokens)
    return resp.text if hasattr(resp, 'text') else str(resp)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    f = request.files.get('file')
    if not f:
        return redirect(url_for('index'))
    uid = str(uuid.uuid4())[:8]
    filename = f"{uid}.pdf"
    save_path = DATA_DIR / filename
    f.save(save_path)
    text = extract_text_from_pdf(save_path)
    (DATA_DIR / f"{uid}.txt").write_text(text, encoding='utf-8')

    cfg = load_config()
    if cfg.get('mode') == 'cloud':
        # attempt to index to elastic and compute embeddings via Vertex (if configured)
        try:
            es = init_elastic_client(cfg)
            # chunk and optionally compute embeddings
            chunks = chunk_text(text)
            try:
                embed_fn = vertex_get_embeddings_fn(cfg)
            except Exception:
                embed_fn = None
            index_document_to_elastic(es, cfg, uid, f.filename, chunks, embedding_fn=embed_fn)
        except Exception as e:
            print("Elastic indexing failed:", e)

    return redirect(url_for('viewer', doc_id=uid))

@app.route('/doc/<doc_id>')
def viewer(doc_id):
    txt_path = DATA_DIR / f"{doc_id}.txt"
    if not txt_path.exists():
        return "Document not found", 404
    text = txt_path.read_text(encoding='utf-8')
    return render_template('viewer.html', doc_id=doc_id, excerpt=text[:2000])

@app.route('/query', methods=['POST'])
def query():
    data = request.get_json()
    doc_id = data.get('doc_id')
    question = data.get('question','')
    txt_path = DATA_DIR / f"{doc_id}.txt"
    if not txt_path.exists():
        return jsonify({"error":"doc not found"}), 404
    text = txt_path.read_text(encoding='utf-8')
    cfg = load_config()
    if cfg.get('mode') == 'cloud':
        # try elastic + vertex pipeline
        try:
            es = init_elastic_client(cfg)
            try:
                embed_fn = vertex_get_embeddings_fn(cfg)
            except Exception:
                embed_fn = None
            hits = query_elastic(es, cfg, question, top_k=3, embedding_fn=embed_fn)
            # combine hits into prompt for generation
            context = "\n\n".join(hits)
            prompt = f"""You are ScholarAI. Use the context below (excerpts from a research document) to answer the user's question.\n\nContext:\n{context}\n\nQuestion: {question}\n\nAnswer concisely and cite which excerpt (1..n) supports your answer."""
            try:
                aiplatform_client = init_vertex_client(cfg)
                answer = vertex_generate_text(cfg, prompt)
            except Exception as e:
                answer = "(Vertex generation not available) " + str(e) + "\n\nContext:\n" + context
            return jsonify({"answer": answer})
        except Exception as e:
            # fallback to local retrieval
            print('Cloud pipeline failed:', e)
            ans = simple_sentence_retrieval(text, question)
            return jsonify({"answer": ans, "fallback": True})
    else:
        # local
        ans = simple_sentence_retrieval(text, question)
        return jsonify({"answer": ans})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)

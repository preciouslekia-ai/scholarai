# ScholarAI - Elastic + Vertex AI Prototype (Scaffold)

This project is a scaffold that integrates Elastic Search and Google Cloud Vertex AI.
It includes:
- PDF upload and extraction
- Chunking and indexing to Elastic (with optional embeddings)
- Query pipeline that retrieves top passages from Elastic and calls Vertex AI for generation

IMPORTANT: This scaffold **contains placeholders** for Elastic endpoint/API key and GCP project/model.
Please update `config.json` with your credentials and ensure required packages are installed.

## config.json
Edit the `config.json` to include:
- mode: 'cloud' or 'local'
- elastic.host: Your Elastic Cloud endpoint (https://...)
- elastic.api_key: Your Elastic API key
- elastic.index: Index name (default: scholarai_docs)
- gcp.project: GCP project id
- gcp.location: region (e.g. us-central1)
- gcp.embedding_model and generation_model: model names

## Run
1. pip install -r requirements.txt
2. Update config.json
3. python app.py
4. Open http://localhost:8080

## Notes
- Elastic vector search requires index mapping including a dense_vector field named 'embedding'.
- Vertex embedding/generation API usage may require different client calls depending on versions; adapt accordingly.
- This scaffold provides fallbacks: if cloud integration fails, it uses local TF-IDF retrieval.
